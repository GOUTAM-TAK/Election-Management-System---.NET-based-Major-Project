﻿namespace ElectionManagementPortal.Services
{
    public class Validations
    {
        public static bool AgeValidaiotn(int min, int max,DateTime date)
        {
            DateTime today= DateTime.Today;
            int age = today.Year - date.Year;
            if (age > min && age<max)
            {
            return true;}
               
        return false;}
        public static bool UserValidation(HttpContext httpContext, string role,int id=0)
        {
            int? id2 = httpContext.Session.GetInt32("id");
            string checkRole=httpContext.Session.GetString("role");
            if (role.Equals(checkRole))
            {
                if(id != 0)
                {
                    if (id == id2)
                    {
                        return true;
                    }
                    return false;
                }
                    return true;
            }
            return false;
        }
       /* public static bool UserValidation(HttpContext httpContext, string role ,int id)//ove
        {
            int? id2 = httpContext.Session.GetInt32("id");
            string checkRole = httpContext.Session.GetString("role");
            if (role.Equals(checkRole))
            {
                if (id == id2)
                {
                    return true;
                }
            }
            return false;
        }*/

    }
   
}
