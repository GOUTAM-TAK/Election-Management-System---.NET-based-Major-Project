﻿using ElectionManagementPortal.ExceptionHandler;
using ElectionManagementPortal.Model_Views;
using ElectionManagementPortal.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Net.Http;
using System.Security.Cryptography;

namespace ElectionManagementPortal.Services
{
    public class PartyServiceUtill
    {
        public static async Task<List<SelectListItem>> GetElectionTypeList(IHttpClientFactory httpClientFactory)
        {
            var client = httpClientFactory.CreateClient("api");
            List<SelectListItem> list = new List<SelectListItem>();
            var response = await client.GetAsync("api/Elections/UpComingElectionsList");
            if (response.IsSuccessStatusCode)
            {
                var list2 = await response.Content.ReadFromJsonAsync<List<Election>>();
                if (list2 != null)
                {
                    foreach (var election in list2)
                    {
                        SelectListItem item = new SelectListItem(text: election.ElectionName, value: election.ElectionId.ToString());
                        list.Add(item);
                    }
                    return list;
                }
            }
            throw new ElectionPortalException(response.RequestMessage.ToString());
        }
        public static async Task<string> DeleteParty(int id, IHttpClientFactory httpClientFactory)
        {
            var client = httpClientFactory.CreateClient("api");
            var response = await client.DeleteAsync($"api/Parties/DeleteParty/{id}");
            if (response.IsSuccessStatusCode)
            {
                return "Successfully Deleted !!";
            }
            throw new ElectionPortalException("Something wrong in Deletion !!");

        }

    }
    public class VoterServicesUtill
    {
        public static async Task<Voter> GetVoterAsync(IHttpClientFactory _httpClientFactory, int? id)
        {

            var client = _httpClientFactory.CreateClient("api");
            var response = await client.GetAsync($"api/Voters/{id}");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<Voter>();
            }
            throw new ElectionPortalException("Server problem!!Try after some time.");

        }
        public static async Task<string> UpdateVoterAsync(IHttpClientFactory _httpClientFactory, Voter voter)
        {
            var client = _httpClientFactory.CreateClient("api");
            var response = await client.PutAsJsonAsync<Voter>($"api/Voters/{voter.Id}", voter);
            if (response.IsSuccessStatusCode)
            {
                return "successfully Updated!!";
            }
            throw new ElectionPortalException("Something wrong in update!!");
        }
        public static async Task<string> DeleteVoterAsync(IHttpClientFactory _httpClientFactory, int? id)
        {
            var client = _httpClientFactory.CreateClient("api");
            var response = await client.DeleteAsync($"api/Voters/{id}");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsStringAsync();
            }
            throw new ElectionPortalException("Something wrong in Delete!!");
        }
        public static async Task<List<GetCandidateList>> GetCandidateListForVotingAsync(IHttpClientFactory _httpClientFactory, int Eid, int? Vid)
        {
            var client = _httpClientFactory.CreateClient("api");
            var response = await client.GetAsync($"api/Candidates/GetCandidatesListForVoting/{Eid}/{Vid}");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<List<GetCandidateList>>();
            }
            throw new ElectionPortalException("Something wrong in Fetching OnGoingElectionsList !!");
        }
        public static async Task<string> VoteNow(IHttpClientFactory _httpClientFactory, int id, int cid, int eid)
        {
            var client = _httpClientFactory.CreateClient("api");
            Vote vote = new Vote();
            vote.VoteTimeStamp = DateTime.Now;
            vote.ElectionId = eid;
            vote.CandidateId = cid;
            vote.VoterId = id;
            var response = await client.PostAsJsonAsync<Vote>($"api/Votes", vote);
            if (response.IsSuccessStatusCode)
            {
                var msg = response.Content.ReadFromJsonAsync<string>();
                return "Successfully Register your vote!! " + msg;
            }
            throw new ElectionPortalException("Something wrong in voting !!" + response.Content.ReadFromJsonAsync<string>());
        }

    }

    public class AdminServiceUtill
    {
        public static async Task<Admin> GetAdminAsync(IHttpClientFactory _httpClientFactory, int? id)
        {

            var client = _httpClientFactory.CreateClient("api");
            var response = await client.GetAsync($"api/Admins/{id}");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<Admin>();
            }
            throw new ElectionPortalException("Server problem!!Try after some time.");

        }
        public static async Task<string> UpdateAdminAsync(IHttpClientFactory _httpClientFactory, Admin admin)
        {

            var client = _httpClientFactory.CreateClient("api");
            var response = await client.PutAsJsonAsync<Admin>($"api/Admins/{admin.Id}", admin);
            if (response.IsSuccessStatusCode)
            {
                Console.WriteLine(response.Content.ReadAsStringAsync());
                return "successfully updated!!";
            }
            throw new ElectionPortalException("Server problem!!Try after some time." + await response.Content.ReadFromJsonAsync<string>());

        }



    }

    public class ElectionServiceUtill
    {
        public static async Task<List<Election>> GetOnGoingElectionListAsync(IHttpClientFactory _httpClientFactory)
        {
            var client = _httpClientFactory.CreateClient("api");
            var response = await client.GetAsync($"api/Elections/OnGoingElectionsList");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<List<Election>>();
            }
            throw new ElectionPortalException("Something wrong in Fetching OnGoingElectionsList !!");
        }
        public static async Task<List<Election>> CompletedElectionsListAsync(IHttpClientFactory _httpClientFactory)
        {
            var client = _httpClientFactory.CreateClient("api");
            var response = await client.GetAsync($"api/Elections/CompletedElectionsList");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<List<Election>>();
            }
            throw new ElectionPortalException("Something wrong in Fetching OnGoingElectionsList !!");
        }
        public static async Task<string> AddNewElectionAsync(IHttpClientFactory _httpClientFactory, Election election)
        {

            var client = _httpClientFactory.CreateClient("api");
            var response = await client.PostAsJsonAsync<Election>("api/Elections", election);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<string>();
            }
            throw new ElectionPortalException("Server problem!!Try after some time." + await response.Content.ReadFromJsonAsync<string>());

        }
        public static async Task<string> UpdateElectionAsync(IHttpClientFactory _httpClientFactory, Election election)
        {

            var client = _httpClientFactory.CreateClient("api");
            var response = await client.PutAsJsonAsync<Election>($"api/Elections/{election.ElectionId}", election);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<string>();
            }
            throw new ElectionPortalException("Server problem!!Try after some time." + await response.Content.ReadFromJsonAsync<string>());

        }
        public static async Task<Election> GetElectionAsync(IHttpClientFactory _httpClientFactory, int id)
        {

            var client = _httpClientFactory.CreateClient("api");
            var response = await client.GetAsync($"api/Elections/{id}");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<Election>();
            }
            throw new ElectionPortalException("Server problem!!Try after some time." + await response.Content.ReadFromJsonAsync<string>());

        }
        public static async Task<List<Election>> GetAllElectionsAsync(IHttpClientFactory _httpClientFactory)
        {

            var client = _httpClientFactory.CreateClient("api");
            var response = await client.GetAsync($"api/Elections");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<List<Election>>();
            }
            throw new ElectionPortalException("Server problem!!Try after some time." + await response.Content.ReadFromJsonAsync<string>());

        }
        public static async Task<List<Election>> GetUpComimngElectionsAsync(IHttpClientFactory _httpClientFactory)
        {

            var client = _httpClientFactory.CreateClient("api");
            var response = await client.GetAsync($"api/Elections/UpComingElectionsList");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<List<Election>>();
            }
            throw new ElectionPortalException("Server problem!!Try after some time." + await response.Content.ReadFromJsonAsync<string>());

        }

    }
    public class ElectionResultServiceUtill
    {
        public static async Task<List<GetElectionResult>> GetElectionResultByElectionIdAsync(IHttpClientFactory _httpClientFactory, int eid)
        {

            var client = _httpClientFactory.CreateClient("api");
            var response = await client.GetAsync($"api/ElectionsResults/GetElectionsResultsByElectionId");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<List<GetElectionResult>>();
            }
            throw new ElectionPortalException("Server problem!!Try after some time." + await response.Content.ReadFromJsonAsync<string>());

        }


        public static async Task<List<GetElectionResult>> GetElectionResultByConstituency(IHttpClientFactory _httpClientFactory, int cid)
        {

            var client = _httpClientFactory.CreateClient("api");
            var response = await client.GetAsync($"api/ElectionsResults/GetElectionsResultsByConstituencyId/{cid}");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<List<GetElectionResult>>();
            }
            throw new ElectionPortalException("Server problem!!Try after some time." + await response.Content.ReadFromJsonAsync<string>());

        }
        public static async Task<List<GetElectionResult>> GetElectionResultByCandidate(IHttpClientFactory _httpClientFactory, int cid)
        {

            var client = _httpClientFactory.CreateClient("api");
            var response = await client.GetAsync($"api/ElectionsResults/GetElectionsResultsByCandidateId/{cid}");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<List<GetElectionResult>>();
            }
            throw new ElectionPortalException("Server problem!!Try after some time." + await response.Content.ReadFromJsonAsync<string>());

        }
        public static async Task<List<GetElectionResult>> GetElectionResultByParty(IHttpClientFactory _httpClientFactory, int pid)
        {

            var client = _httpClientFactory.CreateClient("api");
            var response = await client.GetAsync($"api/ElectionsResults/GetElectionsResultsByPartyId/{pid}");
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<List<GetElectionResult>>();
            }
            throw new ElectionPortalException("Server problem!!Try after some time." + await response.Content.ReadFromJsonAsync<string>());

        }

    }
}
