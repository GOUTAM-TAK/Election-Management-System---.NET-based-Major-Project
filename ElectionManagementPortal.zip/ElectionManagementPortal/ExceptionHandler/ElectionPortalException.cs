﻿namespace ElectionManagementPortal.ExceptionHandler
{
    public class ElectionPortalException :ApplicationException
    {
        public ElectionPortalException(string message) : base(message) { }
    }
}
