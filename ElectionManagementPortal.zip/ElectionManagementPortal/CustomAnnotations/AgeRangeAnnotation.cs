﻿using System.ComponentModel.DataAnnotations;

namespace CustomAnnotations
{
    [AttributeUsage(AttributeTargets.Property |AttributeTargets.Field |AttributeTargets.Parameter, AllowMultiple = false)]
    public class AgeRangeAttribute :ValidationAttribute
    {
        public int MinAge { get; set; }
        public int MaxAge { get; set; }

        public AgeRangeAttribute(int minAge, int maxAge)
        {
            MinAge = minAge;
            MaxAge = maxAge;
        }
        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            if (value is DateTime dateofbirth)
            {
                int age = CalculateAge(dateofbirth);
                if (age < MinAge || age > MaxAge)
                {
                    return new ValidationResult($"Age must be between {MinAge} and {MaxAge} years");
                }
              
            }
            return ValidationResult.Success;
        }
        private static int CalculateAge(DateTime dateOfBirth) 
        {
            DateTime today = DateTime.Today;
            int age = today.Year-dateOfBirth.Year;
            if(dateOfBirth.Date>today.AddYears(-age)) 
            {
                age--;
            }
            return age;
        }
    }
}
