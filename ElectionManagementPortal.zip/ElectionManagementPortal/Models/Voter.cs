﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace ElectionManagementPortal.Models
{
    public class Voter
    {

            [Key]
            public int Id { get; set; }
        [Required(ErrorMessage = "First Name Required")]
        [MaxLength(50, ErrorMessage = "Max length 50 char.")]
        public string FirstName { get; set; } = null!;
        [Required(ErrorMessage = "Last Name Required")]
        [MaxLength(50, ErrorMessage = "Max length 50 char.")]
        public string LastName { get; set; } = null!;

        [Required(ErrorMessage = "Gender Required")]
        [MaxLength(10, ErrorMessage = "Max length 10 char.")]
        public string Gender { get; set; } = null!;

        [Required(ErrorMessage = "Phone number Required")]
        [RegularExpression("^[789][0-9]{9}", ErrorMessage = "Enter correct Mobile number")]

        public string PhoneNo { get; set; } = null!;

        [Required(ErrorMessage = "Email Required")]
        [EmailAddress]
        [MaxLength(250)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password Required")]
        [PasswordPropertyText]
        [MaxLength(100)]
        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$", ErrorMessage = "Password should contain Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Confirm Password Required")]
        [Compare("Password", ErrorMessage = "Password doesn't match")]

        public string ConfirmPassword { get; set; }
        [Required(ErrorMessage = "Address Required")]
        [MaxLength(250)]
        public string Address { get; set; } = null!;

            [Required(ErrorMessage = "Constituency Required")]
            public int ConstituencyId { get; set; } 
        [DataType(DataType.Date)]
        [Required(ErrorMessage = "Date of Birth Required")]
        [CustomAnnotations.AgeRange(18,90,ErrorMessage ="Age must be less than 90 and more than 18")]
        public DateTime DateOfBirth { get; set; }

             [Required(ErrorMessage = "Aadhar Card Number Required")]
        [RegularExpression("^[2-9][0-9]{3}[0-9]{4}[0-9]{4}$",ErrorMessage ="should be 12 digit in this format : 0000000000000000 ")]
            public long AadharNo { get; set; }

        [BindNever]
        public List<SelectListItem> ConstituencyList { get; set; }

    }
}
