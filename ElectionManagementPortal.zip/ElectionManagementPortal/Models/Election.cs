﻿using System.ComponentModel.DataAnnotations;

namespace ElectionManagementPortal.Models
{
    public class Election
    {
        [Key]
        public int ElectionId { get; set; }
        [Required(ErrorMessage = "Name is Required")]
        [MaxLength(50, ErrorMessage = "Max length 150 char.")]
        public string ElectionName { get; set; }
        [Required(ErrorMessage = "Required")]
        [MaxLength(50, ErrorMessage = "Max length 200 char.")]
        public string Description { get; set; }
        [Required(ErrorMessage = "Required")]
        public DateTime StartDateTime { get; set; }
        [Required(ErrorMessage = "Required")]
        public DateTime EndDateTime { get; set; }
        [Required(ErrorMessage = "Required")]
        public string ElectionStatus { get; set; } 
    }
    public enum ElectionEnum
    {
        UP_COMING,ON_GOING,COMPLETED
    }
}
