﻿using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ElectionManagementPortal.Models
{
    public class Party
    {
        [Key]
        public int PartyId { get; set; }
        [Required(ErrorMessage = "First Name Required")]
        [MaxLength(200, ErrorMessage = "Max length 200 char.")]

        public string PartyName { get; set; }
        [Required(ErrorMessage = "First Name Required")]
        [MaxLength(150, ErrorMessage = "Max length 150 char.")]

        public string LeaderName { get; set; }
        [Required(ErrorMessage = "Required")]
        [DataType(DataType.Date)]
        public DateTime FoundedYear { get; set; }
        [Required(ErrorMessage = "Email Required")]
        [EmailAddress]
        [MaxLength(250)]
        public string Email { get; set; }
        [Required(ErrorMessage = "Password Required")]
        [PasswordPropertyText]
        [MaxLength(100)]
        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$", ErrorMessage = "Password should contain Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Confirm Password Required")]
        [Compare("Password", ErrorMessage = "Password doesn't match")]
        [BindNever]
        public string ConfirmPassword { get; set; }
        [MaxLength(200, ErrorMessage = "Max length 200 char.")]

        public string? PartyDscription { get; set; }

       
    }
   
}
