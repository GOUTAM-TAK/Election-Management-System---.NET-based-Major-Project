﻿using System.ComponentModel.DataAnnotations;

namespace ElectionManagementPortal.Models
{
    public class Vote
    {
        [Key]
        public int VoteId { get; set; }

        public int VoterId { get; set; }

        public int CandidateId { get; set; }

        public int ElectionId { get; set; }

        public DateTime VoteTimeStamp { get; set; }

       
    }
}
