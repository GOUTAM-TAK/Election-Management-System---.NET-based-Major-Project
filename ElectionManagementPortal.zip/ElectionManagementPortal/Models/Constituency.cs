﻿using System.ComponentModel.DataAnnotations;

namespace ElectionManagementPortal.Models
{
    public class Constituency
    {
        [Key]
        public int ConstituencyId { get; set; }
        [Required(ErrorMessage = "Name required")]
        [MaxLength(150, ErrorMessage = "Max length 150 char.")]
        public string ConstituencyName { get; set; } 
    }
}
