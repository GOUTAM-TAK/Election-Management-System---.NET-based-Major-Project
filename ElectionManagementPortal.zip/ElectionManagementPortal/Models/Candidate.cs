﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using CustomAnnotations;

namespace ElectionManagementPortal.Models
{
    public  class Candidate
    {
        [ReadOnly(true)]
        public int Id { get; set; }
        [Required(ErrorMessage = "First Name Required")]
        [MaxLength(50, ErrorMessage = "Max length 50 char.")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Last Name Required")]
        [MaxLength(50,ErrorMessage ="Max length 50 char.")]
        public string LastName { get; set; } 
        [Required(ErrorMessage = "Gender Required")]
        [MaxLength(10, ErrorMessage = "Max length 10 char.")]
        public string Gender { get; set; } 
        [Required(ErrorMessage = "Phone number Required")]
        [RegularExpression("^[789][0-9]{9}", ErrorMessage ="Enter correct Mobile number")]
        public string PhoneNo { get; set; } 
        [Required(ErrorMessage = "Email Required")]
        [EmailAddress]
        [MaxLength(250)]
        public string Email { get; set; } 
        [Required(ErrorMessage = "Password Required")]
        [PasswordPropertyText]
        [MaxLength(100)]
        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$",ErrorMessage = "Password should contain Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character")]
        public string Password { get; set; } 
        [Required(ErrorMessage ="Confirm Password Required")]
        [Compare("Password",ErrorMessage ="Password doesn't match")]
        
        public string ConfirmPassword { get; set; } 
        [Required(ErrorMessage = "Address Required")]
        [MaxLength(250)]
        public string Address { get; set; } 
        [Required(ErrorMessage = "Constituency Required")]
        [DisplayName("Constituency")]
        public int ConstituencyId { get; set; }
        [Required(ErrorMessage = "Election Name Required")]
        [DisplayName("Election Name")]
        public int ElectionId { get; set; }
        [Required(ErrorMessage = "Date of Birth Required")]
     //   [AgeRange(18,90,ErrorMessage ="Age must be betwen 21 to 90.")]
        [DataType(DataType.Date)]
     
        public DateTime DateOfBirth { get; set; }
        [Required(ErrorMessage = "Party Name Required")]
        public int PartyId { get; set; }
        [BindNever]
        public List<SelectListItem>ConstituencyList { get; set; }
        [BindNever]
        public List<SelectListItem> ElectionsList { get; set; }

    }
}
