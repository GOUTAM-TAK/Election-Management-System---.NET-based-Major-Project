﻿namespace ElectionManagementPortal.Models
{
    public class ElectionsResult
    {
        public int ResultId { get; set; }

        public int ElectionId { get; set; }

        public int CandidateId { get; set; }

        public long TotalVotes { get; set; }

        public decimal PercentageVotes { get; set; }

        public int ConstituencyId { get; set; }
          }
}
