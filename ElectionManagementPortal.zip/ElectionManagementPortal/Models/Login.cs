﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace ElectionManagementPortal.Models
{
    public class Login
    {
        [Required(ErrorMessage = "Email Required")]
        [EmailAddress]
        [MaxLength(250)]
        public string Email { get; set; }
        [Required(ErrorMessage = "Password Required")]
        [PasswordPropertyText]
        [MaxLength(100)]
        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$", ErrorMessage = "Password should contain Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Confirm Password Required")]
        [Compare("Password", ErrorMessage = "Password doesn't match")]
        [BindNever]
        public string ConfirmPassword { get; set; }

    }
}
