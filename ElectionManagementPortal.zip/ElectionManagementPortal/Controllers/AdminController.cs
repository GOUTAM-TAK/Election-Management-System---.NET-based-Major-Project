﻿using ElectionManagementPortal.Models;
using ElectionManagementPortal.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Security.Cryptography;

namespace ElectionManagementPortal.Controllers
{
    public class AdminController : Controller
            {
        private readonly IHttpClientFactory _httpClientFactory;//by developer

        public AdminController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }
        // GET: Admin/Welcome/{id}
        public async Task<ActionResult> Welcome(int aid)
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin", aid))
                {

                    var admin = await AdminServiceUtill.GetAdminAsync(_httpClientFactory, aid);
                    return View(admin);
                  

                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }

      
        // GET: AdminController/Edit/5
        public async Task<ActionResult> Edit1()
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin"))
                {
                    int? id1 = HttpContext.Session.GetInt32("id");
                    var admin = await AdminServiceUtill.GetAdminAsync(_httpClientFactory,id1 );
                    return View(admin);


                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }

        // POST: AdminController/Edit/5
        [HttpPost]
     
        public async Task<ActionResult> Edit1(Admin admin)
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin", admin.Id))
                {

                    var msg = await AdminServiceUtill.UpdateAdminAsync(_httpClientFactory, admin);
                  //  TempData["msg"]=msg;
                    return RedirectToAction("WelcomeAdmin");


                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }
        
        // Election_Section start

        public ActionResult ElectionSection()
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin"))
                {
                    return View();
                  
                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }

        public async Task<ActionResult<List<Election>>> ElectionList()
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin"))
                {

                    var list = await ElectionServiceUtill.GetAllElectionsAsync(_httpClientFactory);
                    if (list.Count == 0)
                        TempData.Add("msg", "No Any Election Register yet!!");
                    return View(list);
                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }
        public ActionResult AddNewElection()
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin"))
                {

                 
                    return View();
                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }
        [HttpPost]
        public async Task<ActionResult<List<Election>>> AddNewElection(Election election)
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin"))
                {

                    var msg = await ElectionServiceUtill.AddNewElectionAsync(_httpClientFactory, election);
                  
                        TempData.Add("msg", msg);
                    return RedirectToAction("ElectionSection");
                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }
        public async Task<ActionResult<List<Election>>> UpComingElectionsList()
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin"))
                {

                    var list = await ElectionServiceUtill.GetUpComimngElectionsAsync(_httpClientFactory);
                    if (list.Count == 0)
                        TempData.Add("msg", "No Any Election Register yet!!");
                    return View(list);
                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }
        public async Task<ActionResult<List<Election>>> StartElectionPhase1(int eid)
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin"))
                {

                    var election = await ElectionServiceUtill.GetElectionAsync(_httpClientFactory, eid);
                   
                    return View(election);
                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }
        [HttpPost]
        public async Task<ActionResult> StartElectionPhase1(Election election)
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin"))
                {

                    var msg = await ElectionServiceUtill.UpdateElectionAsync(_httpClientFactory, election);
                    TempData.Add("msg", msg);
                    return RedirectToActionPermanent("ElectionSection");
                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }

        public async Task<ActionResult<List<Election>>> OnGoingElectionsList()
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin"))
                {

                    var list = await ElectionServiceUtill.GetOnGoingElectionListAsync(_httpClientFactory);
                    if (list.Count == 0)
                        TempData.Add("msg", "No Any Election OnGoing !!");
                    return View(list);
                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }
        public async Task<ActionResult<Election>> StopElection(int eid)
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin"))
                {

                    var election = await ElectionServiceUtill.GetElectionAsync(_httpClientFactory, eid);

                    return View(election);
                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }
        [HttpPost]
        public async Task<ActionResult> StopElection(Election election)
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin"))
                {

                    var msg = await ElectionServiceUtill.UpdateElectionAsync(_httpClientFactory, election);
                    TempData.Add("msg", msg);
                    return RedirectToActionPermanent("ElectionSection");
                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }



        //Result_Section start

        public ActionResult ResultSection()
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin"))
                {
                    return View();

                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }
        

             public async Task<ActionResult> CompletedElectionsList1()
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "admin"))
                {

                    var list = await ElectionServiceUtill.CompletedElectionsListAsync(_httpClientFactory);
                    if (list.Count == 0)
                        TempData.Add("msg", "No Any Election OnGoing !!");
                    return View(list);
                }
                return RedirectToActionPermanent("AdminLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }



        // GET: AdminController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }








        // POST: AdminController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
