﻿using ElectionManagementPortal.Models;
using ElectionManagementPortal.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.IO;
using System.Net.Http;
using System.Net.Http.Json;

namespace ElectionManagementPortal.Controllers
{
    public class SignUpController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;//by developer

        public SignUpController(IHttpClientFactory httpClientFactory)
        {

            _httpClientFactory = httpClientFactory;
        }
        public IActionResult Index()
        {
            return View();
        }

        
        public IActionResult SignUpParty()
        {

            return View();
        }
         [HttpPost]            //http://Localhost:port/SignUp/SignUpParty
        public async Task<IActionResult> SignUpParty(Party party)
        {
            var client = _httpClientFactory.CreateClient("api");
            var response = await client.PostAsJsonAsync<Party>("api/Parties", party);
            if(response.IsSuccessStatusCode)
            {
                TempData.Add("msg", "Successfully Register,Login here!!");
                return RedirectToAction("PartyLogin","Login");
            }
            else if(response.StatusCode.Equals(StatusCodes.Status406NotAcceptable))
            {
                ViewBag.Msg = "Email already register !!";
                return View();
            }
            else
            {
                TempData.Add("msg","Somthing Wrong happen !! Try after sometime.");
            }
            return RedirectToAction("Index", "Home");
        }
        public async Task<ActionResult<IEnumerable<Constituency>>> SignUpCandidate()
        {
            try
            {
                var client = _httpClientFactory.CreateClient("api");
                var response = await client.GetAsync("api/Constituencies");
                if (response.IsSuccessStatusCode)
                {
                    var item = await response.Content.ReadFromJsonAsync<List<Constituency>>();
                    //  ViewBag.ConstituencyList = item;
                    List<SelectListItem> list = new List<SelectListItem>();
                    foreach (var i in item)
                    {
                        SelectListItem itemlist = new SelectListItem(value: i.ConstituencyId.ToString(), text: i.ConstituencyName);
                        list.Add(itemlist);
                    }


                    Candidate model = new Candidate();
                    model.ConstituencyList = list;
                    model.ElectionsList = await PartyServiceUtill.GetElectionTypeList(_httpClientFactory);
                    return View(model);

                }

                return RedirectToAction("Error", "Home");
            }
            catch(Exception ex)
            {
                return RedirectToAction("Error", "Home");
            }
           
        }
         [HttpPost] //http://Localhost:port/SignUp/SignUpParty
        public async Task<IActionResult> SignUpCandidate(Candidate candidate)
        {
            if (Services.Validations.AgeValidaiotn(21, 90, candidate.DateOfBirth))
            {
                var client = _httpClientFactory.CreateClient("api");
            var response = await client.PostAsJsonAsync<Candidate>("api/Candidates", candidate);
            if (response.IsSuccessStatusCode)
            {
                TempData.Add("msg", "Successfully Register,Login here!!");
                return RedirectToAction("CandidateLogin", "Login");
            }
            else if (response.StatusCode.Equals(StatusCodes.Status406NotAcceptable))
            {
                TempData.Add("msg","Email already register !!");
                return View();
            }
            else
            {
                TempData.Add("msg", "Somthing Wrong happen !! Try after sometime.");
            }
            return RedirectToAction("Index", "Home");
            }
            TempData.Add("msg", "Age must be between 21 to 90 !!");
            return RedirectToAction("SignUpCandidate");
        }
    
    public async Task<ActionResult<IEnumerable<Constituency>>> SignUpVoter()
    {
        var client = _httpClientFactory.CreateClient("api");
        var response = await client.GetAsync("api/Constituencies");
        if (response.IsSuccessStatusCode)
        {
            var item = await response.Content.ReadFromJsonAsync<List<Constituency>>();
            //  ViewBag.ConstituencyList = item;
            List<SelectListItem> list = new List<SelectListItem>();
            foreach (var i in item)
            {
                SelectListItem itemlist = new SelectListItem(value: i.ConstituencyId.ToString(), text: i.ConstituencyName);
                list.Add(itemlist);
            }
            Voter model = new Voter();
            model.ConstituencyList = list;

            return View(model);

        }
            return RedirectToAction("Error", "Home");

        }
    [HttpPost] //http://Localhost:port/SignUp/SignUpParty
    public async Task<IActionResult> SignUpVoter(Voter voter)
    {
            if (Services.Validations.AgeValidaiotn(18, 90, voter.DateOfBirth))
            {


                var client = _httpClientFactory.CreateClient("api");
                var response = await client.PostAsJsonAsync<Voter>("api/Voters", voter);
                if (response.IsSuccessStatusCode)
                {
                    TempData.Add("msg", "Successfully Register,Login here!!");
                    return RedirectToAction("VoterLogin", "Login");
                }
                else if (response.StatusCode.Equals(StatusCodes.Status406NotAcceptable))
                {
                    TempData.Add("msg", "Email already register !!");
                    return View();
                }
                else
                {
                    TempData.Add("msg", "Somthing Wrong happen !! Try after sometime.");
                }

                return RedirectToAction("Index", "Home");
            }
            TempData.Add("msg", "Age must be between 18 to 90 !!");
            return RedirectToAction("SignUpVoter");
    }
}
}
