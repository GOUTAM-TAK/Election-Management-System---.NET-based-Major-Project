﻿using ElectionManagementPortal.Model_Views;
using ElectionManagementPortal.Models;
using ElectionManagementPortal.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.IO;
using System.Net.Http;

namespace ElectionManagementPortal.Controllers
{
    public class PartyController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;//by developer

        public PartyController(IHttpClientFactory httpClientFactory)
        {

            _httpClientFactory = httpClientFactory;
        }
        // GET: Party/id
        public async Task<ActionResult> Welcome()
        {
           if(Validations.UserValidation(HttpContext,"party"))
            {
               var id= HttpContext.Session.GetInt32("id");
                var client = _httpClientFactory.CreateClient("api");
               var party= await client.GetFromJsonAsync<Party>($"api/Parties/{id}");
                return View(party);
            }
            return RedirectToActionPermanent("PartyLogin","Login");
        }
        [HttpGet]
        public async Task<ActionResult> RegisterCandidate(int id)
        {
            if (Validations.UserValidation(HttpContext, "party"))
            {
                var client = _httpClientFactory.CreateClient("api");
                var response = await client.GetAsync("api/Constituencies");
                if (response.IsSuccessStatusCode)
                {
                    var item = await response.Content.ReadFromJsonAsync<List<Constituency>>();
                    //  ViewBag.ConstituencyList = item;
                    List<SelectListItem> list = new List<SelectListItem>();
                    foreach (var i in item)
                    {
                        SelectListItem itemlist = new SelectListItem(value: i.ConstituencyId.ToString(), text: i.ConstituencyName);
                        list.Add(itemlist);
                    }
                    Candidate model = new Candidate();
                    model.ConstituencyList = list;
                    model.PartyId = id;
                   model.ElectionsList = await PartyServiceUtill.GetElectionTypeList(_httpClientFactory);
                    return View(model);

                }

                return RedirectToAction("Error", "Home");
            }
            return RedirectToActionPermanent("PartyLogin", "Login");
        }
        [HttpPost]
        public async Task<IActionResult> RegisterCandidate(Candidate candidate)
        {
            if (Validations.UserValidation(HttpContext, "party"))
            {
                if (Services.Validations.AgeValidaiotn(21, 90, candidate.DateOfBirth))
                {
                    candidate.PartyId = (int)HttpContext.Session.GetInt32("id");

                    var client = _httpClientFactory.CreateClient("api");
                    var response = await client.PostAsJsonAsync<Candidate>("api/Candidates", candidate);
                    if (response.IsSuccessStatusCode)
                    {
                        TempData.Add("msg", "Successfully Register!");
                        return RedirectToAction("Welcome", "Party");
                    }
                    else if (response.StatusCode == System.Net.HttpStatusCode.NotAcceptable)
                    {
                     //   Console.WriteLine(response.Content.ReadAsStringAsync());
                        TempData.Add("msg", "Email already register !!");
                     return   RedirectToAction("RegisterCandidate");
                    }
                    else
                    {
                     
                        TempData.Add("msg", "Somthing Wrong happen !! Try after sometime.");
                    }
                    return RedirectToAction("Index", "Home");
                }
                TempData.TryAdd("msg", "Age must be between 21 to 90 !!");
                
                return RedirectToAction("RegisterCandidate");
            }
            return RedirectToActionPermanent("PartyLogin", "Login");
        }

        // GET: Party/GetCandidatesList/5
        public async Task<ActionResult> GetCandidatesList(int id)
        {
            if (Validations.UserValidation(HttpContext, "party",id))//for Autherization check
            {
                var client = _httpClientFactory.CreateClient("api");
                var response = await client.GetAsync($"api/Candidates/GetCandidateByPartyId/{id}");
                if (response.IsSuccessStatusCode)
                {
                    var item = await response.Content.ReadFromJsonAsync<List<GetCandidateList>>();
                    return View(item);
                }
                TempData["msg"] = "Server Problem..Retry after some time!!";
                
                return RedirectToAction("Welcome");
            }
            return RedirectToActionPermanent("PartyLogin", "Login");
        }

        // GET: Party/DeleteParty
        public async Task<ActionResult> DeleteParty(int id)
        {
            if (Validations.UserValidation(HttpContext, "party",id))
            {

                var client = _httpClientFactory.CreateClient("api");
                var party = await client.GetFromJsonAsync<Party>($"api/Parties/{id}");
                return View(party);
            }
            return RedirectToActionPermanent("PartyLogin", "Login");
        }

        // POST: PartyController/DeleteParty
        [HttpPost]
       
        public async Task<ActionResult> DeleteParty(Party party)
        {
            try
            {
               string msg=await PartyServiceUtill.DeleteParty(party.PartyId, _httpClientFactory);
                HttpContext.Session.Clear();
                return RedirectToAction("Home");
            }
            catch
            {
                return View();
            }
        }

        // GET: PartyController/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            if (Validations.UserValidation(HttpContext, "party",id))
            {
              
                var client = _httpClientFactory.CreateClient("api");
                var party = await client.GetFromJsonAsync<Party>($"api/Parties/{id}");
                return View(party);
            }
            return RedirectToActionPermanent("PartyLogin", "Login");
        }

        // POST: PartyController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Party party)
        {
            if (Validations.UserValidation(HttpContext, "party", party.PartyId))//for Autherization check
            {
                var client = _httpClientFactory.CreateClient("api");
                var response = client.PutAsJsonAsync<Party>($"api/Parties/{party.PartyId}", party);
                if(response.IsCompletedSuccessfully)
                {
                    TempData["msg"] = "Successfully Updated !!";
                    return RedirectToAction("Welcome");
                }
                TempData["msg"] = "Something Wrong!!";
                return RedirectToAction("Welcome");
                   
                              
            }
            return RedirectToActionPermanent("PartyLogin", "Login");
        }

        // GET: DeleteCandidate/Delete/5
        public async Task<ActionResult> DeleteCandidate(int id)
        {
            if (Validations.UserValidation(HttpContext, "party"))
            {

                var client = _httpClientFactory.CreateClient("api");
                var candidate = await client.GetFromJsonAsync<Candidate>($"api/Candidates/GetCandidate/{id}");
                return View(candidate);
            }
            return RedirectToActionPermanent("PartyLogin", "Login");
        }

        // POST: PartyController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteCandidate(int? id)
        {
            if (Validations.UserValidation(HttpContext, "party"))//for Autherization check
            {
                var client = _httpClientFactory.CreateClient("api");
                var msg = await client.DeleteAsync($"api/Parties/{id}");
                if (msg.IsSuccessStatusCode)
                {
                    TempData["msg"] = "Successfully Deleted !!";
                    return RedirectToAction("GetCandidatesList");
                }
                TempData["msg"] = "Something Wrong!!";
                return RedirectToAction("Welcome");


            }
            return RedirectToActionPermanent("PartyLogin", "Login");
        }
        
    }
}
