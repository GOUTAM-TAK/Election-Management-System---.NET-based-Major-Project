﻿using ElectionManagementPortal.Models;
using ElectionManagementPortal.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ElectionManagementPortal.Controllers
{
    public class VoterController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;//by developer

        public VoterController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }
        // GET: Voter/Welcome
        public async Task<ActionResult> Index()
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "voter"))
                {
                    var id = HttpContext.Session.GetInt32("id");
                    var voter = await VoterServicesUtill.GetVoterAsync(_httpClientFactory, id);
                    return View(voter);
                  
                }
                return RedirectToActionPermanent("VoterLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg",ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }
            

             // GET: VoterController/Edit/5
        public async Task<ActionResult> Edit(int id)
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "voter"))
                {
                  
                    var voter = await VoterServicesUtill.GetVoterAsync(_httpClientFactory, id);
                    return View(voter);
                  
                }
                return RedirectToActionPermanent("VoterLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }

        // POST: VoterController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Voter voter)
        {
            try
            {   var msg=VoterServicesUtill.UpdateVoterAsync(_httpClientFactory, voter);
                TempData.Add("msg", msg);
                return RedirectToAction(nameof(Index));
            }
            catch(Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }

        // GET: VoterController/Delete/5
        public async Task<ActionResult> Delete(int id)
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "voter"))
                {

                    var voter = await VoterServicesUtill.GetVoterAsync(_httpClientFactory, id);
                    return View(voter);

                }
                return RedirectToActionPermanent("VoterLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }

        // POST: VoterController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int? id)
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "voter"))
                {
                    var msg=VoterServicesUtill.DeleteVoterAsync(_httpClientFactory, id);

                TempData.Add("msg", msg);
                return RedirectToAction(nameof(Index));
            }
                return RedirectToActionPermanent("VoterLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }

        public async Task<ActionResult> VotingPhase1(int id)
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "voter",id))
                {
                    var ElectionList = await ElectionServiceUtill.GetOnGoingElectionListAsync(_httpClientFactory);
                    if(ElectionList.Count==0)
                    TempData.Add("msg", "No Any Election Going On!!");
                  
                    return View(ElectionList);
                }
                return RedirectToActionPermanent("VoterLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }
        public async Task<ActionResult> VotingPhase2(int Eid)
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "voter"))
                {
                    var Vid = HttpContext.Session.GetInt32("id");
                    var List = await VoterServicesUtill.GetCandidateListForVotingAsync(_httpClientFactory,Eid, Vid);
                    if (List.Count == 0)
                        TempData.Add("msg", "No Any Candidate Contesting the Election From Your Constituency!!");
                    ViewBag.id = HttpContext.Session.GetInt32("id");
                    return View(List);
                }
                return RedirectToActionPermanent("VoterLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }
        public async Task<ActionResult> VotingPhase3(int id,int cid,int eid)
        {
            try
            {
                if (Validations.UserValidation(HttpContext, "voter",id))
                {
                   
                    var msg = await VoterServicesUtill.VoteNow(_httpClientFactory,id,cid,eid);
                   
                        TempData.Add("msg",msg);

                    return RedirectToActionPermanent("Logout", "Home");
                }
                return RedirectToActionPermanent("VoterLogin", "Login");
            }
            catch (Exception ex)
            {
                TempData.Add("msg", ex.Message);
                return RedirectToActionPermanent("Error", "Home");
            }
        }
    }
}
