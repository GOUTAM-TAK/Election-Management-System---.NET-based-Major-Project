﻿using ElectionManagementPortal.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using System.Net.Http;

namespace ElectionManagementPortal.Controllers
{
    public class LoginController : Controller
    {
       
        private readonly IHttpClientFactory _httpClientFactory;//by developer

        public LoginController( IHttpClientFactory httpClientFactory)
        {
           
            _httpClientFactory = httpClientFactory;
        }
        public IActionResult VoterLogin()
        {

            return View();
        }
        [HttpPost]//POST : Login/VoterLogin
        public async Task<ActionResult> VoterLogin(Login voter)
        {
            var client = _httpClientFactory.CreateClient("api");
            var response = await client.PostAsJsonAsync<Login>("api/Voters/LogInVoter", voter);
            if (response.IsSuccessStatusCode)
            {
                string responseBody = await response.Content.ReadAsStringAsync();
                JObject json = JObject.Parse(responseBody);
                int id = Convert.ToInt32(json["id"]);

                HttpContext.Session.SetInt32("id", id);
                HttpContext.Session.SetString("role","voter");
                return RedirectToAction("Index", "Voter");
            }
            ViewBag.Msg = "Invalid username or password!!";
            return View();
        }

        public IActionResult CandidateLogin()
        {

            return View();
        }
        [HttpPost]//POST : Login/CandidateLogin
        public async Task<ActionResult> CandidateLogin(Login candidate)
        {
            var client = _httpClientFactory.CreateClient("api");
            var response = await client.PostAsJsonAsync<Login>("api/Candidates/LogInCandidate", candidate);
            if (response.IsSuccessStatusCode)
            {
                string responseBody = await response.Content.ReadAsStringAsync();
                JObject json = JObject.Parse(responseBody);
                int id = Convert.ToInt32(json["id"]);

               HttpContext.Session.SetInt32("id", id);
               HttpContext.Session.SetString("role","candidate");
                return RedirectToAction("Welcome", "Candidate");
            }
            ViewBag.Msg = "Invalid username or password!!";
            return View();
        }
        public IActionResult AdminLogin()
        {

            return View();
        }
        [HttpPost]//POST : Login/AdminLogin
        public async Task<ActionResult> AdminLogin(Login admin)
        {
            var client = _httpClientFactory.CreateClient("api");
            var response = await client.PostAsJsonAsync<Login>("api/Admins/LogInAdmin", admin);
            if (response.IsSuccessStatusCode)
            {
                string responseBody = await response.Content.ReadAsStringAsync();
                JObject json = JObject.Parse(responseBody);
                int id = Convert.ToInt32(json["id"]);

                HttpContext.Session.SetInt32("id", id);
                HttpContext.Session.SetString("role","admin");
                return RedirectToAction("WelcomeAdmin", "Admin",new {aid=id});
            }
            ViewBag.Msg = "Invalid username or password!!";
            return View();
        }
        public IActionResult PartyLogin()
        {

            return View();
        }
        [HttpPost]//POST : Login/PartyLogin
        public async Task<ActionResult> PartyLogin(Login party)
        {
            var client = _httpClientFactory.CreateClient("api");
            var response = await client.PostAsJsonAsync<Login>("api/Parties/LogInParty", party);
            if (response.IsSuccessStatusCode)
            {
                string responseBody = await response.Content.ReadAsStringAsync();
                JObject json = JObject.Parse(responseBody);
                int id = Convert.ToInt32(json["id"]);

                HttpContext.Session.SetInt32("id", id);
                HttpContext.Session.SetString("role", "party");
                return RedirectToAction("Welcome", "Party", id);
            }
            ViewBag.Msg = "Invalid username or password!!";
            return View();
            
        }
    }
}
