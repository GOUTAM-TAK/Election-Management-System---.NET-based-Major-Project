﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ElectionManagementPortal.Controllers
{
    public class ElectionsController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;//by developer

        public ElectionsController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }
        // GET: ElectionsController
        public ActionResult ElectionList()
        {

            return View();
        }

        // GET: ElectionsController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ElectionsController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ElectionsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ElectionsController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ElectionsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ElectionsController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ElectionsController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
