﻿using ElectionManagementPortal.Models;
using Microsoft.AspNetCore.Routing.Matching;

namespace ElectionManagementPortal.Model_Views
{
    public class GetCandidateList
    {
        public Candidate Candidate {  get; set; }
        public string PartyName { get; set; }
        public string ConstituencyName { get; set; }

        public string ElectionName { get; set; }
    }
}
