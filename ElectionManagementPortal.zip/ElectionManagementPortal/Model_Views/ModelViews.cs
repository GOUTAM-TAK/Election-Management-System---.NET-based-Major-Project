﻿using ElectionManagementPortal.Models;

namespace ElectionManagementPortal.Model_Views
{
    public class ModelViews
    {
    }
    public class GetElectionResult
    {
        public ElectionsResult ElectionRsult { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public string Email { get; set; }
        public string PartyName { get; set; }
        public string ElectionName { get; set; }

        public string ConstituencyName { get; set; }

    }

}
